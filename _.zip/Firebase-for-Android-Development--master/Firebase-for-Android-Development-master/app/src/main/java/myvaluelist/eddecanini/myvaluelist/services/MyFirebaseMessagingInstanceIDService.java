package myvaluelist.eddecanini.myvaluelist.services;

import com.google.firebase.iid.FirebaseInstanceIdService;

public class MyFirebaseMessagingInstanceIDService extends FirebaseInstanceIdService {
}
