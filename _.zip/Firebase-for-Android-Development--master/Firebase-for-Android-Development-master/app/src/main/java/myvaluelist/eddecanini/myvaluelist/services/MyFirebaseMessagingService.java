package myvaluelist.eddecanini.myvaluelist.services;

import com.google.firebase.messaging.FirebaseMessagingService;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
}
